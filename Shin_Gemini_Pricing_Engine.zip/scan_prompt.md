# SHIN SINGLE-SCAN PROMPT TEMPLATE

Analyze ALL supplied scan information together.

## SCAN TYPE
{{SCAN_TYPE}}

## BARCODE
{{BARCODE_OR_NULL}}

## USER MARKET
Country/market: {{MARKET}}
Currency: {{CURRENCY}}
Language: {{LANGUAGE}}

## USER INPUT
Shelf price: {{SHELF_PRICE_OR_NULL}}
Additional user information: {{USER_INPUT_OR_NULL}}

## IMAGE
The supplied image is Shin's selected cropped scan image.
Image sharpness score: {{SHARPNESS_SCORE_OR_NULL}}

## TASK
Identify the scanned product as accurately as possible.

If a barcode is supplied, use the exact barcode as a primary search
signal. If an image is supplied, inspect it for product name, brand,
model, variant, size, pack count, specifications, barcode, condition,
and identifying text.

When Google Search is available:
1. Search the exact barcode when available.
2. Confirm identity against image and other evidence.
3. Search current relevant retail offers in the user's market.
4. Distinguish direct retailers from marketplace sellers.
5. Preserve advertised currency and pricing structure.
6. Find customer review information when available.
7. Return supporting source information.

Do not invent missing information.
Do not silently convert currencies.
Do not treat marketplace, used, refurbished, auction, or historical
prices as equivalent to current direct retail offers.

Return only the structured object defined by the response schema.
